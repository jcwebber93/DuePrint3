M569.5 P123.0 S3000 A0 R100 D58623 V0
M83 ; relative
M42 P0 S1 ; turn off blower
G4 S5
G1 E40 F120
M42 P0 S0 ; turn on blower
G1 E20 F120