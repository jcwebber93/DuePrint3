; Extruder step test (time-based)
; Start speed: 2.0 mm/s
; End speed: 100.0 mm/s
; Steps: 10, Extrude time: 1.0s per step

M83 ; relative extrusion mode
G92 E0 ; reset extruder position
M400 ; wait for ready

; Step 1/10 - 2.00 mm/s for 1.0s (2.00 mm)
G1 E2.000 F120.0

; Step 2/10 - 12.89 mm/s for 1.0s (12.89 mm)
G1 E12.889 F773.3

; Step 3/10 - 23.78 mm/s for 1.0s (23.78 mm)
G1 E23.778 F1426.7

; Step 4/10 - 34.67 mm/s for 1.0s (34.67 mm)
G1 E34.667 F2080.0

; Step 5/10 - 45.56 mm/s for 1.0s (45.56 mm)
G1 E45.556 F2733.3

; Step 6/10 - 56.44 mm/s for 1.0s (56.44 mm)
G1 E56.444 F3386.7

; Step 7/10 - 67.33 mm/s for 1.0s (67.33 mm)
G1 E67.333 F4040.0

; Step 8/10 - 78.22 mm/s for 1.0s (78.22 mm)
G1 E78.222 F4693.3

; Step 9/10 - 89.11 mm/s for 1.0s (89.11 mm)
G1 E89.111 F5346.7

; Step 10/10 - 100.00 mm/s for 1.0s (100.00 mm)
G1 E100.000 F6000.0

M400 ; wait for all moves to complete
; Test complete