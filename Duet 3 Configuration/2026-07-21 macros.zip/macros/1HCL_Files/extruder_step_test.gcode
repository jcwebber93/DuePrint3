; Extruder step speed test
; Start speed: 2.0 mm/s
; End speed: 100.0 mm/s
; Steps: 10, Extrude per step: 2.0 mm

M83 ; relative extrusion mode
G92 E0 ; reset extruder position
M400 ; wait for ready

; Step 1/10 - 2.00 mm/s
G1 E2.000 F120.0

; Step 2/10 - 12.89 mm/s
G1 E2.000 F773.3

; Step 3/10 - 23.78 mm/s
G1 E2.000 F1426.7

; Step 4/10 - 34.67 mm/s
G1 E2.000 F2080.0

; Step 5/10 - 45.56 mm/s
G1 E2.000 F2733.3

; Step 6/10 - 56.44 mm/s
G1 E2.000 F3386.7

; Step 7/10 - 67.33 mm/s
G1 E2.000 F4040.0

; Step 8/10 - 78.22 mm/s
G1 E2.000 F4693.3

; Step 9/10 - 89.11 mm/s
G1 E2.000 F5346.7

; Step 10/10 - 100.00 mm/s
G1 E2.000 F6000.0

M400 ; wait for all moves to complete
; Test complete