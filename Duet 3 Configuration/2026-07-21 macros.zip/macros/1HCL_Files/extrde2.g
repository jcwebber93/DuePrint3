M569.5 P123.0 S2500 A0 R500 D58623 V0
G4 S1
M302 P1
T0 P0
M569 P123.0 S1  ; extruder forward         1HCL TESTING
M42 P1 S1   ; enable extruder
M83
G1 E10 F1200
G1 E-10 F1200
G1 E10 F1200
M569 P123.0 S0  ; extruder back
G1 E10 F1200
G1 E-10 F1200
G1 E10 F1200
G1 E-10 F1200
;M98 P"/macros/1HCL_files/print_extrusion_test.g"