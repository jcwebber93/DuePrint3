; Extruder step test (time-based)
; Start speed: 2.0 mm/s
; End speed: 50.0 mm/s
; Steps: 10, Extrude time: 1.0s per step

M83 ; relative extrusion mode
G92 E0 ; reset extruder position
M400 ; wait for ready

; Step 1/10 - 2.00 mm/s for 1.0s (2.00 mm)
G1 E2.000 F120.0

; Step 2/10 - 7.33 mm/s for 1.0s (7.33 mm)
G1 E7.333 F440.0

; Step 3/10 - 12.67 mm/s for 1.0s (12.67 mm)
G1 E12.667 F760.0

; Step 4/10 - 18.00 mm/s for 1.0s (18.00 mm)
G1 E18.000 F1080.0

; Step 5/10 - 23.33 mm/s for 1.0s (23.33 mm)
G1 E23.333 F1400.0

; Step 6/10 - 28.67 mm/s for 1.0s (28.67 mm)
G1 E28.667 F1720.0

; Step 7/10 - 34.00 mm/s for 1.0s (34.00 mm)
G1 E34.000 F2040.0

; Step 8/10 - 39.33 mm/s for 1.0s (39.33 mm)
G1 E39.333 F2360.0

; Step 9/10 - 44.67 mm/s for 1.0s (44.67 mm)
G1 E44.667 F2680.0

; Step 10/10 - 50.00 mm/s for 1.0s (50.00 mm)
G1 E50.000 F3000.0

M400 ; wait for all moves to complete
; Test complete