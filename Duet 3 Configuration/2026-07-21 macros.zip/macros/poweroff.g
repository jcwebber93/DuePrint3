echo state.status
if state.status == "idle"
    echo true
else
echo false
