G4 S1
M302 P1
T1 P0
M569 P123.0 S1  ;
M42 P1 S1 ; enable
M83
;G1 E10 F1200
;G1 E-10 F1200
;M98 P"/macros/10_load.g"
;G1 E-20 F600
;T0
M98 P"/macros/print_extrusion_test.g"
;T1
G4 P500
;M400
M98 P"/macros/print_extrusion_test.g"
G4 P500
M98 P"/macros/print_extrusion_test.g"
G4 P500
M98 P"/macros/print_extrusion_test.g"
G4 P500
M98 P"/macros/print_extrusion_test.g"
G4 P500
M98 P"/macros/print_extrusion_test.g"
G4 P500
M98 P"/macros/print_extrusion_test.g"
G4 P500
M98 P"/macros/print_extrusion_test.g"

;M83
;M569.5 P123.0 S2500 A0 R500 D1055 V0
;M302 P1
;T1 P0
;M569 P123.0 S1  ; fwd
;M42 P1 S1 ; enable
;G1 E10 F600
;M569 P123.0 S0
;G1 E10 F600