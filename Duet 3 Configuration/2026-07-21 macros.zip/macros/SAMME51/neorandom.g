var red = random(254)
var blue = random(254)
var green = random (254)
M150 E0 R{var.red} U{var.blue} B{var.green}
echo var.red ^ "," ^ var.blue ^ "," ^ var.green